﻿
using Zoo.ContextEF;
using Zoo.EF.App;
using Zoo.EF.ZooEF;

MangeZooContext ContextDTO = new MangeZooContext();
AppRun appRun = new AppRun(ContextDTO); 
appRun.Run();