﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.AnimalSpecies;
using Zoo.Model.Sections;
using Zoo.Model.Tikets;
using Zoo.Model.Zoos;
using Zoo.Model.Zoos.ZooEntityMaps;

namespace Zoo.ContextEF
{
    public class MangeZooContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("server=.;Initial Catalog=ManageZoo;Integrated Security=True;TrustServerCertificate=Yes");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ZooEntityMap).Assembly);
        }
        public DbSet<AnimalSpecie> animalSpecies { get; set; }
        public DbSet<Section> sections  { get; set; }
        public DbSet<TiketPay> tiketPays  { get; set; } 
        public DbSet<ZooAnmails> ZooAnmails { get; set; }
    } 
}
