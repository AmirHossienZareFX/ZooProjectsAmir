﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;

namespace Zoo.EF.Report
{
    public class GetAllReportAllAnimalZoo(MangeZooContext ContextDTO)
    {
        public void ReportGetAll()
        {

        }
    }
}
