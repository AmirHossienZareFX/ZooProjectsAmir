﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;
using Zoo.EF.App;
using Zoo.EFModel.Zoos.ZooAnmailsDTOs;
using Zoo.Model.Sections;
using Zoo.Model.Zoos;

namespace Zoo.EF.ZooEF
{
    public class GetAllShowZoo(MangeZooContext ContextDTO)
    {

        public void AddZoo()
        {
            Console.WriteLine("Add a new zoo Info... ");
            Console.WriteLine("Name Zoo");
            string NameZoo = Console.ReadLine();
            Console.WriteLine("Address zoo");
            string AddressZoo = Console.ReadLine();

            var result = new ZooAnmails()
            {
                NameZoo = NameZoo,
                AddressZoo = AddressZoo,
            };
            Console.WriteLine("Sussessfully Created");
            ContextDTO.Set<ZooAnmails>().Add(result);
            ContextDTO.SaveChanges();
        }
        public void EditeZoo()
        {
            Console.WriteLine("Insert ID to Find: ");
            var FindID = int.Parse(Console.ReadLine());
            var zoo = ContextDTO.Set<ZooAnmails>().Find(FindID);
            if (zoo != null)
            {
                Console.WriteLine("Block . Please enter new details to edit:");

                Console.WriteLine($" Block Name: {zoo.NameZoo}");

                Console.Write("Enter new Block Name: ");
                var Namezoos = Console.ReadLine();
                if (!string.IsNullOrEmpty(Namezoos))
                {
                    zoo.NameZoo = Namezoos;
                }
                ContextDTO.SaveChanges();
                Console.Write("Enter new Block Name: ");
                var Addresszoo = Console.ReadLine();
                if (!string.IsNullOrEmpty(Namezoos))
                {
                    zoo.AddressZoo = Addresszoo;
                }
                ContextDTO.SaveChanges();
                Console.WriteLine("Successfully updated the block.");
            }
            Console.WriteLine("Succesfully Created ");
            Console.WriteLine("\n");
            Console.WriteLine("Get ID Zoo  ");
            int GetIDZoo = int.Parse(Console.ReadLine());

            Console.WriteLine("Get New Name");
            string Namezoo = Console.ReadLine();

            Console.WriteLine("Get New Address");
            string Address = Console.ReadLine();

            var getEditezoo = new ZooAnmails
            {
                AddressZoo = Address,
                NameZoo = Namezoo,
            };
            ContextDTO.Set<ZooAnmails>().Find(getEditezoo);
            ContextDTO.SaveChanges();
        }

        public void ShowAllZoo()
        {
            var ShowAllSetion = ContextDTO.Set<Section>().OrderByDescending(_ => _.Id);
            var showAll = ContextDTO.Set<ZooAnmails>().OrderBy(_ => _.Id);
            if (showAll != null && showAll.Any())
            {
                foreach (var item in showAll) 
                {  
                    Console.WriteLine($" Id Zoo Unit:{item.Id}" +
                        $" \n Name:{item.NameZoo} " + 
                        $"\n AddressZoo{item.AddressZoo} "); 
                       
                    if (ShowAllSetion != null && ShowAllSetion.Any())
                    { 
                        foreach (var sectionItem in ShowAllSetion) 
                        { 
                            Console.WriteLine($"ID sectio{sectionItem.Id} \n" +
                                $" Area section{sectionItem.Area} \n" +
                                $" AnimalCount{sectionItem.AnimalCount} \n" +
                                $" Description :{sectionItem.Description} ");
                        }
                    }
                }
            }
        }
    }
}
