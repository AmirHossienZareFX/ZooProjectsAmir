﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;
using Zoo.Migrations;
using Zoo.Model.AnimalSpecies;

namespace Zoo.EF.AnimalSpeciesEF
{
    public class EFGetAllShowAnimalSpecies(MangeZooContext ContextDTO)
    {
        public void AddAllShowAnimalSpecies()
        {
            Console.WriteLine("Create |A| AnimalSpecies");
            Console.WriteLine("Please Enter Name");
            string nameAnimalSpecies = Console.ReadLine();

            var result = new AnimalSpecie()
            {
                NameAnimalSpecies=nameAnimalSpecies
            };
            ContextDTO.Set<AnimalSpecie>().Add(result);
            ContextDTO.SaveChanges();
        }

        public void EditeAllShowAnimalSpecies()
        {
            Console.WriteLine("Insert ID to Find: ");
            var FindID = int.Parse(Console.ReadLine());
            var section = ContextDTO.Set<AnimalSpecie>().Find(FindID);
            if (section != null)
            {
                Console.WriteLine(" AnimalSpecies . Please enter new details to edit:");

                Console.Write("Enter new nameAnimalSpecies : ");
                var nameAnimalSpecies = Console.ReadLine();
                if (!string.IsNullOrEmpty(nameAnimalSpecies))
                {
                    section.NameAnimalSpecies = nameAnimalSpecies;
                    Console.WriteLine("Please Enter nameAnimalSpecies : ");
                }
                ContextDTO.SaveChanges();
                Console.WriteLine("Successfully updated the nameAnimalSpecies.");
            }
            Console.WriteLine("Succesfully Created ");
            Console.WriteLine("\n");
        }
    }
}
