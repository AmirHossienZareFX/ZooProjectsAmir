﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;
using Zoo.EF.AnimalSpeciesEF;
using Zoo.EF.SectionsEF;
using Zoo.EF.ZooEF;

namespace Zoo.EF.App
{
    public class AppRun(MangeZooContext contextDTO )
    {
        private readonly GetAllShowZoo getAllShowZoo = new GetAllShowZoo(contextDTO);
        private readonly EFGetAllShowSection GetAllsection = new EFGetAllShowSection(contextDTO);
        private readonly EFGetAllShowAnimalSpecies getAllShowAnimalSpecies = new EFGetAllShowAnimalSpecies(contextDTO);
        public void ManueApp()
        {
            Console.WriteLine("[1]Add ZooInfo ");
            Console.WriteLine("[2]Edite ZooChange ");
            Console.WriteLine("[3]Show All Zoo");
            Console.WriteLine("[4]Add Section");
            Console.WriteLine("[5]Edite Section");
            Console.WriteLine("[6]add AnimalSpecies");
            Console.WriteLine("[7]Edite ShowAnimalSpecies");
            Console.WriteLine("[8]");
            Console.WriteLine("Exit");
            Console.WriteLine("Select Opertion");
        }
        public void Run()
        {
            while (true)
            {
                ManueApp();
                Console.WriteLine("If You Select Lsit[1] to [10]");
                var Chose = Console.ReadLine();
                switch (Chose)
                {
                    case "1":
                        getAllShowZoo.AddZoo();
                        break;
                    case "2":
                        getAllShowZoo.EditeZoo();
                        break;
                    case "3":
                        getAllShowZoo.ShowAllZoo();
                        break;
                    case "4":
                        GetAllsection.AddSection();
                        break;
                    case "5":
                        GetAllsection.EditeSection();
                        break;
                    case "6":
                        getAllShowAnimalSpecies.AddAllShowAnimalSpecies();
                        break;
                    case "7":
                        getAllShowAnimalSpecies.EditeAllShowAnimalSpecies();
                        break;
                    case "0":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please Choise One List! 1 to 10 and exite = enter [0] ");
                        break;
                }
            }



        }
    }
}
