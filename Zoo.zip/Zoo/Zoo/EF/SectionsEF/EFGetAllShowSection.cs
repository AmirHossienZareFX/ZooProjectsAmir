﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;
using Zoo.Model.Sections;
using Zoo.Model.Zoos;

namespace Zoo.EF.SectionsEF
{
    public class EFGetAllShowSection(MangeZooContext ContextDTO)
    {
        public void AddSection()
        {

            Console.WriteLine("Add ID");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Area Section");
            double area = double.Parse(Console.ReadLine());
            Console.WriteLine("AnimalCount section");
            int animalCount = int.Parse(Console.ReadLine());
            Console.WriteLine("description Section");
            string description = Console.ReadLine();
            Console.WriteLine("Sussessfully Created");
            var result = new Section()
            {
                Area = area,
                AnimalCount = animalCount,
                Description = description,
                Id=id,
            };
            foreach (var item in ContextDTO.sections)
            {
                Console.WriteLine($" ID {item.Id} area {item.Area} animalCount {item.AnimalCount} desction{item.Description}");
            }
            var zoo = ContextDTO.ZooAnmails.FirstOrDefault(_=>_.Id == id);
            ContextDTO.Set<Section>().Add(result); 
            ContextDTO.SaveChanges();
        }
        public void EditeSection()
        {
            Console.WriteLine("Insert ID to Find: ");
            var FindID = int.Parse(Console.ReadLine());
            var section = ContextDTO.Set<Section>().Find(FindID);
            if (section != null)
            {
                Console.WriteLine("section . Please enter new details to edit:");

                Console.WriteLine($" section area: {section.Area}");

                Console.Write("Enter new section area: ");
                double area = double.Parse(Console.ReadLine());
                if (area != null)
                {
                    section.Area = area;
                    Console.WriteLine("Please Enter Area example : 1.52");
                }
                Console.WriteLine("");

                Console.WriteLine("Enter new section AnimalCount :");
                int animalCount = int.Parse(Console.ReadLine());
                if (animalCount != null)
                {
                    section.AnimalCount = animalCount;
                    Console.WriteLine("Please Enter animalCount : ");
                }

                Console.Write("Enter new : ");
                var description = Console.ReadLine();
                if (!string.IsNullOrEmpty(description))
                {
                    section.Description = description;
                    Console.WriteLine("Please Enter description : ");
                }
                ContextDTO.SaveChanges();
                Console.WriteLine("Successfully updated the section.");
            }

            Console.WriteLine("Succesfully Created ");
            Console.WriteLine("\n");
        }

    }
}
