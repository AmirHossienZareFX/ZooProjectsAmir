﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zoo.Migrations
{
    /// <inheritdoc />
    public partial class CreatData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Section_Zoo_ZooAnmailID",
                table: "Section");

            migrationBuilder.DropIndex(
                name: "IX_Section_ZooAnmailID",
                table: "Section");

            migrationBuilder.AddColumn<int>(
                name: "zooAnmailsId",
                table: "Section",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Section_zooAnmailsId",
                table: "Section",
                column: "zooAnmailsId");

            migrationBuilder.AddForeignKey(
                name: "FK_Section_Zoo_zooAnmailsId",
                table: "Section",
                column: "zooAnmailsId",
                principalTable: "Zoo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Section_Zoo_zooAnmailsId",
                table: "Section");

            migrationBuilder.DropIndex(
                name: "IX_Section_zooAnmailsId",
                table: "Section");

            migrationBuilder.DropColumn(
                name: "zooAnmailsId",
                table: "Section");

            migrationBuilder.CreateIndex(
                name: "IX_Section_ZooAnmailID",
                table: "Section",
                column: "ZooAnmailID");

            migrationBuilder.AddForeignKey(
                name: "FK_Section_Zoo_ZooAnmailID",
                table: "Section",
                column: "ZooAnmailID",
                principalTable: "Zoo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
