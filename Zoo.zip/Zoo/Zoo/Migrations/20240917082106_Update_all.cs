﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Zoo.Migrations
{
    /// <inheritdoc />
    public partial class Update_all : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_sections_AnimalSpecie_AnimalSpeciesID",
                table: "sections");

            migrationBuilder.DropForeignKey(
                name: "FK_sections_Zoo_ZooAnmailID",
                table: "sections");

            migrationBuilder.DropForeignKey(
                name: "FK_tiketPays_sections_SectionId",
                table: "tiketPays");

            migrationBuilder.DropPrimaryKey(
                name: "PK_sections",
                table: "sections");

            migrationBuilder.DropIndex(
                name: "IX_sections_AnimalSpeciesID",
                table: "sections");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AnimalSpecie",
                table: "AnimalSpecie");

            migrationBuilder.RenameTable(
                name: "sections",
                newName: "Section");

            migrationBuilder.RenameTable(
                name: "AnimalSpecie",
                newName: "Animal");

            migrationBuilder.RenameIndex(
                name: "IX_sections_ZooAnmailID",
                table: "Section",
                newName: "IX_Section_ZooAnmailID");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Section",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "NameAnimalSpecies",
                table: "Animal",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "sectionID",
                table: "Animal",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Section",
                table: "Section",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Animal",
                table: "Animal",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_Animal_sectionID",
                table: "Animal",
                column: "sectionID",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Animal_Section_sectionID",
                table: "Animal",
                column: "sectionID",
                principalTable: "Section",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Section_Zoo_ZooAnmailID",
                table: "Section",
                column: "ZooAnmailID",
                principalTable: "Zoo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tiketPays_Section_SectionId",
                table: "tiketPays",
                column: "SectionId",
                principalTable: "Section",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Animal_Section_sectionID",
                table: "Animal");

            migrationBuilder.DropForeignKey(
                name: "FK_Section_Zoo_ZooAnmailID",
                table: "Section");

            migrationBuilder.DropForeignKey(
                name: "FK_tiketPays_Section_SectionId",
                table: "tiketPays");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Section",
                table: "Section");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Animal",
                table: "Animal");

            migrationBuilder.DropIndex(
                name: "IX_Animal_sectionID",
                table: "Animal");

            migrationBuilder.DropColumn(
                name: "sectionID",
                table: "Animal");

            migrationBuilder.RenameTable(
                name: "Section",
                newName: "sections");

            migrationBuilder.RenameTable(
                name: "Animal",
                newName: "AnimalSpecie");

            migrationBuilder.RenameIndex(
                name: "IX_Section_ZooAnmailID",
                table: "sections",
                newName: "IX_sections_ZooAnmailID");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "sections",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(300)",
                oldMaxLength: 300);

            migrationBuilder.AlterColumn<string>(
                name: "NameAnimalSpecies",
                table: "AnimalSpecie",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AddPrimaryKey(
                name: "PK_sections",
                table: "sections",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AnimalSpecie",
                table: "AnimalSpecie",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_sections_AnimalSpeciesID",
                table: "sections",
                column: "AnimalSpeciesID");

            migrationBuilder.AddForeignKey(
                name: "FK_sections_AnimalSpecie_AnimalSpeciesID",
                table: "sections",
                column: "AnimalSpeciesID",
                principalTable: "AnimalSpecie",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_sections_Zoo_ZooAnmailID",
                table: "sections",
                column: "ZooAnmailID",
                principalTable: "Zoo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_tiketPays_sections_SectionId",
                table: "tiketPays",
                column: "SectionId",
                principalTable: "sections",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
