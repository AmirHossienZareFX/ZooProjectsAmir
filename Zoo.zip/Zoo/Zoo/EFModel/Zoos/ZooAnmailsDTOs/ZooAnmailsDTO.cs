﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.ContextEF;

namespace Zoo.EFModel.Zoos.ZooAnmailsDTOs
{
    public class ZooAnmailsDTO
    {
        public int Id { get; set; }
        public string NameZoo { get; set; }
        public string AddressZoo { get; set; }
    }
}
