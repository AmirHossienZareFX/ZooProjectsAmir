﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.AnimalSpecies;
using Zoo.Model.Sections;

namespace Zoo.Model.Zoos
{
    public class ZooAnmails
    {
        public int Id { get; set; }
        public string NameZoo { get; set; }
        public string AddressZoo { get; set; }
        public int SectionID { get; set; }
        public List<Section> sections { get; set; } = new List<Section>();
    }
}
