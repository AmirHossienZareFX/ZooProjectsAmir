﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.Zoos;

namespace Zoo.Model.Zoos.ZooEntityMaps
{
    public class ZooEntityMap : IEntityTypeConfiguration<ZooAnmails>
    {
        public void Configure(EntityTypeBuilder<ZooAnmails> builder)
        {
            builder.ToTable("Zoo");   
            builder.HasKey(_ => _.Id);   
            builder.Property(_ => _.Id).UseIdentityColumn(); 
            builder.Property(_ => _.AddressZoo).IsRequired().HasMaxLength(400); 
            builder.Property(_ => _.NameZoo).IsRequired().HasMaxLength(100); 
           
     
        
        } 
    } 
}
