﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.Sections;

namespace Zoo.Model.Tikets
{
    public class TiketPay
    {
        public int ID { get; set; } 
        public decimal Price { get; set; }
        public Section Section { get; set; }
    }
}
