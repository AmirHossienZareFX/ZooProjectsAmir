﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.AnimalSpecies;

namespace Zoo.EFModel.AnimalSpecies.AnimalsEntityMap
{
    public class AnimalsEntityMap : IEntityTypeConfiguration<AnimalSpecie>
    {
        public void Configure(EntityTypeBuilder<AnimalSpecie> builder)
        {
            builder.ToTable("Animal");  
            builder.HasKey(_ => _.Id);  
            builder.Property(_ => _.NameAnimalSpecies).IsRequired().HasMaxLength(200);
            builder.HasOne(_ => _.section).WithOne(_=>_.animalSpecies)
                .HasForeignKey<AnimalSpecie>(_=>_.sectionID)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
