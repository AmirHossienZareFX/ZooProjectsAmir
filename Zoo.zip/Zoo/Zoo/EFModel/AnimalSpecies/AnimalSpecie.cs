﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.Sections;
using Zoo.Model.Tikets;
using Zoo.Model.Zoos;

namespace Zoo.Model.AnimalSpecies
{
    public class AnimalSpecie
    {
        #region Method
        public int Id { get; set; }
        public string NameAnimalSpecies { get; set; }
        #endregion
        #region relation
        public int sectionID { get; set; }
        public Section section { get; set; }

        #endregion
    }
}
