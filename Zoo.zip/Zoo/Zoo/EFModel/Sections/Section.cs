﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model.AnimalSpecies;
using Zoo.Model.Zoos;

namespace Zoo.Model.Sections
{
    public class Section
    {
        public int Id { get; set; }
        public double Area { get; set; } 
        public int AnimalCount { get; set; }
        public string Description { get; set; }
        #region MyRegion

        public int AnimalSpeciesID { get; set; }
        public AnimalSpecie animalSpecies { get; set; }
        public int ZooAnmailID { get; set; }
        public ZooAnmails zooAnmails { get; set; } 
        #endregion

    }
}
