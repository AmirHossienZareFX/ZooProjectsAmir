﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo.Model.Sections.SectionEntityMaps
{
    public class SectionEntityMap : IEntityTypeConfiguration<Section>
    {
        public void Configure(EntityTypeBuilder<Section> builder)
        {
            builder.ToTable("Section");
            builder.Property(_ => _.Area).IsRequired().HasMaxLength(300);
            builder.Property(_ => _.AnimalCount).IsRequired().HasMaxLength(200);
            builder.Property(_ => _.Description).IsRequired().HasMaxLength(300);
            builder.HasOne(_ => _.zooAnmails).WithMany(_ => _.sections).HasForeignKey(_ => _.ZooAnmailID).OnDelete(DeleteBehavior.Cascade);

        }
    }
}
